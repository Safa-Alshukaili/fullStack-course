export const UsersData= [
    {
        id: 1,
        name: 'Safa ',
        email: 'Safa@gmail.com',
        password: '12345'
    },

    {
        id: 2,
        name: 'Ali ',
        email: 'Ali@gmail.com',
        password: '12345'
    },

    {
        id: 3,
        name: 'Malaz ',
        email: ' Malaz@gmail.com',
        password: '12345'
    }
];