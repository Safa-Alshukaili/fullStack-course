import user from "../Images/user.png";
const User = () => {

  return (
    <div>
      <img src={user} className="userImage" />
    </div>
  );
};

export default User;
