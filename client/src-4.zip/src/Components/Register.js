import {Form,Input,Button,Container,Row, Col} from "reactstrap";
import { userSchemaValidation } from '../Validations/UserValidations';
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useSelector , useDispatch} from "react-redux";
import { useState } from "react";
import { addUser, deleteUser} from "../Features/UserSlice";
import { Link } from "react-router-dom";


const Register = () => {
  const userList = useSelector((state) => state.users.value);

  const dispatch= useDispatch();

  const [name, setname] = useState("");
  const [email, setemail] = useState("");
  const [password, setpassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");

  
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(userSchemaValidation),
  });

  const handleDelete=(email)=>
  {
    dispatch(deleteUser(email));
  }

  const onSubmit = (data) => {
    try{
      const  UsersData={
        name:data.name,
        email:data.email,
        password:data.password,
      }
      dispatch(addUser(UsersData));

    console.log("Form Data", data);
    alert("Validation all good!");
  }
  catch (error)
   {
      alert("Error occures");
    }
  };

  return (
    <Container fluid>
      <Row className="formrow">
        <Col className="columndiv1" lg="6">
          <Form className="div-form" onSubmit={handleSubmit(onSubmit)}>
            <section className="form">
              <div className="Form-Group">
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  placeholder="Enter your name..."
                  {...register("name", {
                    onChange: (e) => setname(e.target.value),
                  })}
                />
                <p className="error">{errors.name?.message}</p>
              </div>

              <div className="Form-Group">
                <input
                  type="text"
                  className="form-control"
                  id="email"
                  placeholder="Enter your email..."
                  {...register("email", {
                    onChange: (e) => setemail(e.target.value),
                  })}
                />
                <p className="error">{errors.email?.message}</p>
              </div>

              <div className="Form-Group">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  placeholder="Enter your password..."
                  {...register("password", {
                    onChange: (e) => setpassword(e.target.value),
                  })}
                />
                <p className="error">{errors.password?.message}</p>
              </div>

              <div className="Form-Group">
                <input
                  type="password"
                  className="form-control"
                  id="confirm"
                  placeholder="Confirm your password..."
                  {...register("confirmPassword", {
                    onChange: (e) => setconfirmPassword(e.target.value),
                  })}
                />
                <p className="error">{errors.confirmPassword?.message}</p>
              </div>

              <Button color="primary" className="button">
                Register
              </Button>
            </section>
          </Form>
        </Col>
        <Col className="columndiv1" lg="6"></Col>
      </Row>

            <Row>
        <Col md={6}>
          <h2>List of Users</h2>
          <table>
            <tr>
              <th>Name</th>
              <th>email</th>
              <th>password</th>
            </tr>
            <tbody>
              {userList.map((user) => (
                <tr key={user.email}>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>{user.password}</td>

                  <td><Button onClick={() => handleDelete(user.email)}>
                      Delete User
                    </Button></td>
                    <td>
                      <Link to = {`/update/${user.email}/${user.name}/${user.password}`}>
                      <Button>Update</Button>
                      </Link>
                    </td>

                </tr>
              ))}
            </tbody>
          </table>
        </Col>
      </Row>


    </Container>
  );
};

export default Register;
