import {Navbar, Nav, NavItem, NavLink,} from "reactstrap";
import { Link } from "react-router-dom";
import logo from "../Images/logo-t.png";

const Header = () => {

  return (
    <>
    <Navbar className="header">
      <Nav>
        <NavItem>
          <NavLink href="#">
          <img src={logo} className="loginImage" />
          </NavLink>
        </NavItem>

        <NavItem>
          <Link to="/Home">
          Home
          </Link>
        </NavItem>

        <NavItem>
          <Link to="/Profile">
          Profile
          </Link>
        </NavItem>

          <NavItem>
          <Link to="/Register">
          Register
          </Link>
        </NavItem>

        <NavItem>
          <Link to="/Logout">
          Logout
          </Link>
        </NavItem>
      </Nav>
    </Navbar>
    </>


  );
};

export default Header;
