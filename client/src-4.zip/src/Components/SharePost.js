import { Container,Row,Form,FormGroup,Input,Button,
 } from "reactstrap";

const SharePosts = () => {
  return (
    <>
    <Container>
      <Row>
        <Form>
          <FormGroup>
            <Input 
            id ="Share"
            name = "Share"
            type = "Texterea"
            />
            <br></br>
            <Button color="primary">Post IT</Button>
          </FormGroup>
        </Form>
      </Row>
    </Container>
    </>
  );
};

export default SharePosts;
