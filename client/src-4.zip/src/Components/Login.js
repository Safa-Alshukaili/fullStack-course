import { Link } from "react-router-dom";

import logo from "../Images/logo.png";

import{Form,FormGroup,Input,Label,Button, Container, Row,Col} from "reactstrap";

const Login = () => {
   return (
    <div>
      <Container>
      <Form>
        <Row>
          <Col md={3}>
          <img src={logo}/>
          </Col>
        </Row>   

         <Row>
          <Col md={3}>  
          <FormGroup>
            <Label for="email">
              Email
              </Label> 
              <Input
              id="email"
              name="email"
              placeholder="enter email..."
              type="email"
              />
            </FormGroup>        
          </Col>
        </Row>
        <Row>
          <Col md={3}> 
          <FormGroup>
            <Label for="password">
              password
              </Label> 
              <Input
              id="password"
              name="password"
              placeholder="enter password..."
              type="password"
              />   
            </FormGroup>
     </Col>
        </Row>
        <Row>
          <Col md={3}>
          <Button> Login</Button>
          </Col>
        </Row>
        </Form>
        <p className="smalltext">
          no Account? <Link to="/register">sign up now,</Link>
        </p>
      </Container>   
    </div>
  );
            

};

export default Login;
